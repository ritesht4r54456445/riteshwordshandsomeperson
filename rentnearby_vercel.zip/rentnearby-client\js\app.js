const API_URL = '/api';

// Initialize App State
async function initApp() {
  const authBtn = document.getElementById('authBtn');
  
  // Real Supabase Session Fetch
  const { data: { session } } = await supabaseClient.auth.getSession();

  if (session && authBtn) {
    authBtn.textContent = 'Dashboard';
    authBtn.onclick = () => window.location.href = 'dashboard.html';
  } else if (authBtn && !document.getElementById('logoutBtn')) {
    authBtn.textContent = 'Login';
    authBtn.onclick = () => window.location.href = 'auth.html';
  }

  // Handle detailed listing logic if on listing page
  const unlockBtn = document.getElementById('unlockBtn');
  if (unlockBtn) {
    const urlParams = new URLSearchParams(window.location.search);
    const listingId = urlParams.get('id');
    unlockBtn.addEventListener('click', () => attemptUnlock(listingId, session));
  }

  // Handle mock payment success redirection (keeping this for now until real Stripe is integrated)
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('mock_payment') === 'success') {
    const plan = urlParams.get('plan');
    handleMockPaymentSuccess(plan, session);
  }
}

async function handleMockPaymentSuccess(planType, session) {
  if(!session) return;
  // We hit our server mock endpoint that actually updates the database profile
  try {
    await fetch(`${API_URL}/payments/mock-success`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({ userId: session.user.id, planType })
    });
    alert(`Payment successful! You are now subscribed to the ${planType.toUpperCase()} plan.`);
    window.history.replaceState({}, document.title, window.location.pathname);
    if(typeof updateDashboardData === 'function') updateDashboardData();
  } catch (err) {
    console.error(err);
  }
}

async function mockSubscribe(planType) {
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (!session) {
    alert('Please log in first to subscribe.');
    return window.location.href = 'auth.html';
  }
  
  // Simulate Stripe Checkout Redirect
  alert('Redirecting to Stripe Checkout...');
  window.location.href = `dashboard.html?mock_payment=success&plan=${planType}`;
}

async function attemptUnlock(listingId, session) {
  if (!session) {
    alert('You must log in and have a subscription to unlock contacts.');
    window.location.href = 'subscriptions.html';
    return;
  }

  const statusText = document.getElementById('statusText');
  statusText.textContent = "Verifying subscription limit...";

  try {
    const res = await fetch(`${API_URL}/listings/${listingId}/unlock`, {
      headers: { 'Authorization': `Bearer ${session.access_token}` }
    });
    const data = await res.json();
    
    if(res.status === 402) {
      statusText.innerHTML = '<span style="color:var(--primary-color)">Plan limit exhausted. Please upgrade your plan.</span>';
      setTimeout(() => { window.location.href = 'subscriptions.html'; }, 1500);
      return;
    }

    if (data.success) {
      const contactBox = document.getElementById('contactBox');
      contactBox.className = 'revealed-contact';
      contactBox.textContent = data.phone;
      
      document.getElementById('unlockBtn').style.display = 'none';
      statusText.textContent = `Contact Unlocked!`;
    } else {
      statusText.textContent = data.error || 'Server error occurred.';
    }
  } catch(e) {
    statusText.textContent = 'Failed to connect to the server. Ensure backend is running.';
  }
}

// Global Logout
async function logout() {
  await supabaseClient.auth.signOut();
  window.location.href = 'index.html';
}

// Run init
document.addEventListener('DOMContentLoaded', initApp);
