// Supabase Initialization via CDN
const SUPABASE_URL = 'https://geclgerbnlniwatlxngv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdlY2xnZXJibmxuaXdhdGx4bmd2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0NDQyMTUsImV4cCI6MjA5MTAyMDIxNX0.53gYm_pAw0i4H7blzrKFu6ExY5AVlqtWy6r22qZRJrU';

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
