const express = require('express');
const router = express.Router();
const supabase = require('../supabase');

// Middleware to extract Auth Header (Token) and verify it 
// Note: Normally we verify the JWT in Node.js or let Supabase handle it. 
// For simplicity in this mock, we expect the Authorization header to contain the access token
// We fetch the user using supabase.auth.getUser(token)
const requireAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'Missing Authorization header' });

  const token = authHeader.replace('Bearer ', '');
  const { data: { user }, error } = await supabase.auth.getUser(token);

  if (error || !user) return res.status(401).json({ error: 'Invalid token or user' });
  req.user = user;
  next();
};

/**
 * Route: GET /api/listings/:id/unlock
 * Desc: Unlocks the contact for a listing if the user has enough limit.
 */
router.get('/:id/unlock', requireAuth, async (req, res) => {
  const listingId = req.params.id;
  const userId = req.user.id;

  try {
    // 1. Fetch user's profile to check limits
    const { data: profile, error: profileErr } = await supabase
      .from('profiles')
      .select('plan, plan_limit, contacts_used')
      .eq('id', userId)
      .single();

    if (profileErr || !profile) {
      return res.status(400).json({ error: 'User profile not found' });
    }

    // 2. Check if user already unlocked this contact
    const { data: existingUnlock } = await supabase
      .from('unlocks')
      .select('id')
      .eq('user_id', userId)
      .eq('listing_id', listingId)
      .single();

    // 3. Fetch the listing to get the phone number
    const { data: listing, error: listingErr } = await supabase
      .from('listings')
      .select('hidden_contact, owner_id')
      .eq('id', listingId)
      .single();

    if (listingErr || !listing) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    // If owner is trying to view their own listing, just return it
    if (listing.owner_id === userId) {
      return res.json({ success: true, phone: listing.hidden_contact });
    }

    // If already unlocked, just return the contact (don't charge limit)
    if (existingUnlock) {
      return res.json({ success: true, phone: listing.hidden_contact });
    }

    // 4. Verify limit
    if (profile.contacts_used >= profile.plan_limit) {
      return res.status(402).json({ 
        error: 'Plan limit exhausted', 
        message: 'Please upgrade your plan to unlock more contacts.' 
      });
    }

    // 5. Deduct Limit and Record Unlock
    // Increment contacts_used
    const { error: updateErr } = await supabase
      .from('profiles')
      .update({ contacts_used: profile.contacts_used + 1 })
      .eq('id', userId);

    if (updateErr) throw new Error('Error updating profile limits');

    // Insert to unlocks
    const { error: unlockErr } = await supabase
      .from('unlocks')
      .insert({ user_id: userId, listing_id: listingId });

    if (unlockErr) throw new Error('Error recording unlock');

    // 6. Return the contact
    return res.json({ success: true, phone: listing.hidden_contact });
  } catch (error) {
    console.error('Unlock error:', error);
    res.status(500).json({ error: 'Internal server error while unlocking' });
  }
});

module.exports = router;
