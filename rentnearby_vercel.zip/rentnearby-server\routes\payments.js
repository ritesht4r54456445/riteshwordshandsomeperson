const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_mock');
const supabase = require('../supabase');

// Mock plans
const PLANS = {
  basic: { name: 'Basic', limit: 10, priceId: 'price_basic_mock' },
  standard: { name: 'Standard', limit: 25, priceId: 'price_standard_mock' },
  premium: { name: 'Premium', limit: 99999, priceId: 'price_premium_mock' }, // 99999 denotes unlimited for MVP
};

// Start Checkout
router.post('/create-checkout-session', async (req, res) => {
  const { planType, userId } = req.body;
  const plan = PLANS[planType];

  if (!plan) return res.status(400).json({ error: 'Invalid plan type' });

  // In a real app we hit Stripe API `stripe.checkout.sessions.create`
  // For MVP, we will simulate a success URL immediately if no Stripe Key is fully configured.
  // We'll pass the plan limits mock to our webhook logic or direct success page.
  
  // Real implementation stub:
  /*
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{ price: plan.priceId, quantity: 1 }],
    mode: 'payment',
    success_url: `${process.env.CLIENT_URL}/dashboard.html?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.CLIENT_URL}/subscriptions.html`,
    client_reference_id: userId,
    metadata: { planType, limit: plan.limit },
  });
  return res.json({ id: session.id, url: session.url });
  */

  // Mock implementation for immediate frontend testing:
  // We just return a success payload that the frontend can simulate.
  // In a true environment, the webhook handles database update.
  res.json({ 
    success: true, 
    mock_url: `http://localhost:5500/dashboard.html?mock_payment=success&plan=${planType}` 
  });
});

// Real Stripe Webhook stub
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    // Note: requires raw body
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET || 'whsec_mock');
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle successful checkout
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.client_reference_id;
    const { planType, limit } = session.metadata;

    // Give 30 days expiry
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 30);

    // Update user in Supabase
    const { error } = await supabase
      .from('profiles')
      .update({
        plan: planType,
        plan_limit: parseInt(limit),
        contacts_used: 0, // Reset usage on new plan
        plan_expiry: expiry.toISOString()
      })
      .eq('id', userId);
      
    if (error) console.error('Error updating user plan:', error);
  }

  res.json({ received: true });
});

// Quick endpoint to artificially grant a plan for testing without Stripe checkout:
router.post('/mock-success', async (req, res) => {
  const { planType, userId } = req.body;
  const plan = PLANS[planType];
  if (!plan) return res.status(400).json({ error: 'Invalid plan' });

  const expiry = new Date();
  expiry.setDate(expiry.getDate() + 30);

  const { error } = await supabase
    .from('profiles')
    .update({
      plan: planType,
      plan_limit: plan.limit,
      contacts_used: 0,
      plan_expiry: expiry.toISOString()
    })
    .eq('id', userId);

  if (error) return res.status(500).json({ error: error.message });
  res.json({ success: true });
});

// Mock endpoint to purchase a label for a listing
router.post('/mock-label-success', async (req, res) => {
  const { listingId, label } = req.body;
  if (!listingId || !label) return res.status(400).json({ error: 'Missing listingId or label' });

  // First fetch existing listing to append to labels array
  const { data: listing, error: fetchErr } = await supabase
    .from('listings')
    .select('labels')
    .eq('id', listingId)
    .single();

  if (fetchErr || !listing) return res.status(404).json({ error: 'Listing not found' });

  const currentLabels = listing.labels || [];
  if (!currentLabels.includes(label)) {
    currentLabels.push(label);
  }

  const { error: updateErr } = await supabase
    .from('listings')
    .update({ labels: currentLabels })
    .eq('id', listingId);

  if (updateErr) return res.status(500).json({ error: updateErr.message });
  res.json({ success: true });
});

module.exports = router;
