require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
// Need raw body for Stripe webhooks, so we apply express.json() conditionally or globally, but Stripe webhook requires raw.
app.use((req, res, next) => {
  if (req.originalUrl === '/api/payments/webhook') {
    next();
  } else {
    express.json()(req, res, next);
  }
});

// Import Routes
const listingRoutes = require('./routes/listings');
const paymentRoutes = require('./routes/payments');

app.use('/api/listings', listingRoutes);
app.use('/api/payments', paymentRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'RentNearby API is running.' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

module.exports = app;
