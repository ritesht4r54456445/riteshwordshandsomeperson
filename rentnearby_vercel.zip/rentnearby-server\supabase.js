const { createClient } = require('@supabase/supabase-js');

// These should be your Service Role Keys to bypass RLS in the backend securely
const supabaseUrl = process.env.SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || 'YOUR_SUPABASE_SERVICE_ROLE_KEY';

const supabase = createClient(supabaseUrl, supabaseServiceKey);

module.exports = supabase;
